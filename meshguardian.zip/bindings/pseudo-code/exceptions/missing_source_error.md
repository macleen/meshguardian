CLASS MissingSourceError(Exception)
    METHOD __init__(message)
        self.message = message
